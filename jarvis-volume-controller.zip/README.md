<!---
IMPORTANT
=========
This README.md is displayed in the WebStore as well as within Jarvis app
Please do not change the structure of this file
Fill-in Description, Usage & Author sections
Make sure to rename the [en] folder into the language code your plugin is written in (ex: fr, es, de, it...)
For multi-language plugin:
- clone the language directory and translate commands/functions.sh
- optionally write the Description / Usage sections in several languages
-->
## Description
This plugin allows to change volume by voice control
/!\ Amixer that it finds in the ALSA packaging must be installed

## Usage
```
You: Jarvis Change volume Please ?
Jarvis: What level of sound you want ?
You: Mute Please !
Jarvis: ok!
```

## Author
[kevin](http://no.website.com)
# jarvis-volume-control
