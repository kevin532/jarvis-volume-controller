#!/bin/bash
# This file will be automatically sourced at the uninstallation of your plugin
# Use only if you need to undo changes on the user system such as removing software
