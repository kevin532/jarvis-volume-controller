#!/bin/bash
# This file will be automatically sourced each time your plugin is updated
# Use only if you need to perform updates on the user systems to support evolution of your plugin
